#ifndef _ECLIPSE_WCHAR_H
#define _ECLIPSE_WCHAR_H

/* Just the type, not the library: wide *string/char literal* support
 * (L"...", L'...') is a clang frontend feature needing no runtime code
 * at all -- it works as soon as `wchar_t` exists. __WCHAR_TYPE__ is the
 * same builtin macro clang predefines for any target (including this
 * custom "eclipse-dg-none" one) and real wchar.h implementations use to
 * define this typedef, so this mirrors that instead of guessing a width.
 * None of the wide-character *functions* (wprintf, wcslen, mbstowcs,
 * ...) are provided -- add them here if a test needs one.
 */
typedef __WCHAR_TYPE__ wchar_t;

#endif
